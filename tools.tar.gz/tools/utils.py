#!/usr/bin/env python
# -*- coding:utf-8 -*-
__author__ = 'patch'

import sys,hashlib, os, time, datetime, StringIO
import  xlrd,re,xlwt, subprocess,logging

from mongoengine.queryset.visitor import Q
from PIL import Image, ImageOps
from PIL.ExifTags import TAGS
from django.core.files import File

from branch.models import Branch
from go2 import settings
from go2.settings import BASE_DIR,USER_IMAGE_DIR,ALLOWED_HOSTS
from gradeClass.models import Lesson
from regUser.models import *
from teacher.models import Teacher,Login_teacher,Message
from tools.templatetags.filter_gradeClass import get_gradeClass_type
from tools import constant

# Get an instance of a logger
logger = logging.getLogger('utils')

def now2datetime(convert_to_local=True):
    now = long(time.time())
    return timestamp2datetime(now, convert_to_local)

def timestamp2datetime(timestamp, convert_to_local=True):
    ''' Converts UNIX timestamp to a datetime object. '''
    if isinstance(timestamp, (int, long, float)):
        dt = datetime.datetime.utcfromtimestamp(timestamp)
        if convert_to_local:  # 是否转化为本地时间
            dt = dt + datetime.timedelta(hours=8)  # 中国默认时区
        return dt
    return timestamp

def getTeachers(branchId,roleExs=None,includeQuit=None):
    if not roleExs:
        roleExs = [9]
    query = Q(branch=branchId)&Q(status=0)
    if includeQuit == True:
        query = Q(branch=branchId)
    if roleExs and len(roleExs)>0:
        for ex in roleExs:
            query = query&Q(role__ne=ex)
    teachers = Teacher.objects.filter(query).order_by("id")  # @UndefinedVariable
    return teachers

def getDateNow(hours=None):
    #print hours
    if not hours:
        hours = 0
    
    d1 = datetime.datetime.now()
    timeNow = d1+datetime.timedelta(hours=hours)
    #print d1
    #print timeNow
    return timeNow

def getWeekBegin(somedate,isNET=None):
    weekday = somedate.weekday()
    if isNET == 1:
        weekday = weekday
    else:
        if weekday == 0:
            weekday = 6
        else:
            weekday = weekday -1
    weekbegin = somedate - datetime.timedelta(days=weekday)
   
    #logger.log('weekbegin--------------------------------------------------------')
    return weekbegin

def dateOfYearMonth(year,month):
    yd = int(float(year))*365
    md = 0
    if month:
        try:
            md = int(float(month))*30
        except:
            md = 0
        
    days = yd + md
    now = getDateNow()
    ageDate = now - datetime.timedelta(days=days)
    return ageDate 

def str2md5(str):
    try:
        m = hashlib.md5()
        m.update(str)
        return m.hexdigest()
    except:
        return None


def save_log(filename, info):
    txt = info.encode("utf-8")

    dir = os.path.join(settings.BASE_DIR, 'log')
    if not os.path.exists(dir):
        os.mkdir(dir)
    file = os.path.join(dir, filename + ".log")
    if os.path.exists(file):
        file_w = open(file, "a")
    else:
        file_w = open(file, "w")
    file_w.write("\n" + txt)
    file_w.close()

# 课程
def get_gradeClass_from_oid(oid):
    if not oid or len(oid) == 0:
        return GradeClass()
    else:
        try:
            return GradeClass.objects.get(id=oid)
        except:
            return None


# 教室
def get_classroom_from_oid(oid):
    try:
        return Classroom.objects.get(id=oid)
    except:
        return None

def get_branch_from_oid(oid):
    try:
        return Branch.objects.get(id=oid)  # @UndefinedVariable
    except:
        return None

# 老师
def get_teacher_from_oid(oid):
    try:
        return Teacher.objects.get(id=oid)  # @UndefinedVariable
    except:
        return None
    
def getStat(login_teacher,isOwn,tag,beginDate,endDate):
    stat = Stat()
    stat.dayTag = tag
    if isOwn:
        stat.visit = Student.objects.filter(regTeacher=login_teacher.id).filter(regTime__gte=beginDate).filter(regTime__lte=endDate).count()
    else:
        stat.visit = Student.objects.filter(branch=login_teacher.branch).filter(regTime__gte=beginDate).filter(regTime__lte=endDate).count()
    if not stat.visit:
        stat.visit = 0
    if isOwn:
        stat.demo = GradeClass.objects.filter(start_date__gte=beginDate).filter(start_date__lte=endDate).filter(demoIsFinish=1).filter(teacher=login_teacher.id).count()
        #stat.demo = Student.objects.filter(regTeacstatisticlogin_teacher.id).filter(demo__start_date__gte=beginDate).count()
    else:
        stat.demo = GradeClass.objects.filter(start_date__gte=beginDate).filter(start_date__lte=endDate).filter(demoIsFinish=1).filter(branch=login_teacher.branch).count()
        #stat.demo = Student.objects.filter(branch=statisticn_teacher.branch).filter(demo__start_date__gte=beginDate).count()
    if not stat.demo:
        stat.demo = 0
    ct = ContractType.objects.filter(city=login_teacher.cityId).filter(duration=4)
    if isOwn:
        stat.sign = Contract.objects.filter(teacher=login_teacher.id).filter(singDate__gte=beginDate).filter(singDate__lte=endDate).count()
        #stat.sign = Student.objects.filter(regTeacstatisticlogin_teacher.id).filter(contract__singDate__gte=beginDate).count()
    else:
        stat.sign = Contract.objects.filter(branch=login_teacher.branch).filter(singDate__gte=beginDate).filter(singDate__lte=endDate).count()
    if not stat.sign:
        stat.sign = 0
    return stat


def checkCookie(request):
    login_teacher = Login_teacher() 
    username = request.COOKIES.get('username', '')
    if not (username):
        # return HttpResponseRedirect('/travel/login')
        return None
    login_teacher.username = username
    login_teacher.role = int(request.COOKIES.get('role', ''))
    login_teacher.branchName = request.COOKIES.get('branchName', '')
    login_teacher.branchTel = request.COOKIES.get('branchTel', '')
    login_teacher.branch = request.COOKIES.get('branch', '')
    login_teacher.id = request.COOKIES.get('userid', '')
    
    login_teacher.roleName = request.COOKIES.get('roleName', '')
    login_teacher.teacherName = request.COOKIES.get('teacherName', '')
    login_teacher.name2 = request.COOKIES.get('name2', '')
    login_teacher.page = request.COOKIES.get('teacherPage', '')
    login_teacher.cityId = request.COOKIES.get('cityId', '')
    login_teacher.city = request.COOKIES.get('city', '')
    login_teacher.branchSN = request.COOKIES.get('branchSN', '')
    login_teacher.branchType = request.COOKIES.get('branchType', '')
    login_teacher.cityHeadquarter = request.COOKIES.get('cityHeadquarter', '')
    login_teacher.showIncome = request.COOKIES.get('showIncome', '')
    
    login_teacher.cityFA = request.COOKIES.get('cityFA', '')
    login_teacher.cityFR = request.COOKIES.get('cityFR', '')
    login_teacher.cityRT = request.COOKIES.get('cityRT', '')
    login_teacher.cityRB = request.COOKIES.get('cityRB', '')
    login_teacher.cityRB2 = request.COOKIES.get('cityRB2', '')
    return login_teacher



# 顺时针旋转图片90度
def imageRotage(filename):

    img = Image.open(filename)
    img2 = img.rotate(-90,expand=True)
    img2.save(filename)


###########################
#
# 上传图片
#
###########################

def handle_uploaded_image(i,branch_oid,student_oid,type=None,maxlength=None):
        filedate = getDateNow()
        if not maxlength: 
            maxlength = 640 #文件最大宽度默认640px

        # read image from InMemoryUploadedFile
        image_str = ""
        for c in i.chunks():
            image_str += c

        # create PIL Image instance
        imagefile  = StringIO.StringIO(image_str)
        image = None

        try:
            image = Image.open(imagefile)
        except Exception,e:
            print e
            return None,e

        info = None
        exif = {}
        try:
            image._getexif()
            print info
            for tag, value in info.items():
                decoded = TAGS.get(tag, tag)
                exif[decoded] = value
                if decoded == 'DateTime' or decoded == 'DateTimeOriginal':
                    fdate = exif[decoded]
                    filedate = datetime.datetime.strptime(fdate,"%Y:%m:%d %H:%M:%S")

        except Exception,e:
            err = 1    
        x = image.size[0]
        y = image.size[1]
        img_ratio = float(x) / float(y)
        
        # if not RGB, convert
        if image.mode not in ("L", "RGB"):
            image = image.convert("RGB")

        #define file output dimensions (ex 60x60)
        if x>maxlength:
            x = maxlength
            y = x / img_ratio
        if y>maxlength:
            y = maxlength
            x = y * img_ratio
        #get orginal image ratio
        
        # resize but constrain proportions?
        if x==0.0:
            x = y * img_ratio
        elif y==0.0:
            y = x / img_ratio

        # output file ratio
        resize_ratio = float(x) / y
        x = int(x); y = int(y)

        # get output with and height to do the first crop
        if(img_ratio > resize_ratio):
            output_width = x * image.size[1] / y
            output_height = image.size[1]
            originX = image.size[0] / 2 - output_width / 2
            originY = 0
        else:
            output_width = image.size[0]
            output_height = y * image.size[0] / x
            originX = 0
            originY = image.size[1] / 2 - output_height / 2

        #crop
        cropBox = (originX, originY, originX + output_width, originY + output_height)
        image = image.crop(cropBox)

        # resize (doing a thumb)
        image.thumbnail([x, y], Image.ANTIALIAS)

        # re-initialize imageFile and set a hash (unique filename)
        imagefile = StringIO.StringIO()
        filename = i.name

        #save to disk
        userImagePath = None
        if type == constant.FileType.reimburseAttach: #报销附件
            userImagePath = BASE_DIR+USER_IMAGE_DIR+branch_oid+'/reimburse/'
            filename=student_oid+'_a.jpg'
        elif type == constant.FileType.reimburseProof:#报销票据凭证
            userImagePath = BASE_DIR+USER_IMAGE_DIR+branch_oid+'/reimburse/'
            filename=student_oid+'_p.jpg'
        elif student_oid and type != '3': #学生照片
            userImagePath = BASE_DIR+USER_IMAGE_DIR+branch_oid+'/'+student_oid+'/'
            
        else: #校区相册照片
            userImagePath = BASE_DIR+USER_IMAGE_DIR+branch_oid+'/'
            if type != '3': #校区照
                filename = "classroom.jpg"
        if not os.path.exists(userImagePath):
            os.makedirs(userImagePath)
        if type == '4':
            filename = 'refundApp.jpg'
        
        imagefile = open(os.path.join(userImagePath,filename), 'wb+')
        image.save(imagefile,'JPEG', quality=60)
        
        #=======================================================================
        # saveFileName = branch_oid+"/"
        # if student_oid:
        #     saveFileName = saveFileName + student_oid
        # saveFileName = saveFileName + "__"+filename
        #=======================================================================
        
        #=======================================================================
        # 
        # try:
        #     p = subprocess.Popen(["scp",userImagePath+filename,"root@172.16.0.135:/data/backup/zhenpu_crm_pics/users/"+saveFileName],stdout=subprocess.PIPE)
        # except Exception,e:
        #     save_log("debug",str(e))
        #=======================================================================
       # backupFile(userImagePath,filename)
        #=======================================================================
        # try:
        #     remote = "root@172.16.0.135:"+userImagePath
        #     #save_log("debug", userImagePath+filename)
        #     remote = remote[0:len(remote)-1]
        #     #save_log("debug", remote)
        #     p = subprocess.Popen(['rsync','-ave','ssh',userImagePath+filename,remote],stdout=subprocess.PIPE)
        # except Exception,e:
        #     save_log("debug",str(e))
        #=======================================================================
        #output, err = p.communicate()
        return filename,filedate

#backup image file to backup server(rang.jieli360.com)
def backupFile(path,filename):
    try:
            remote = "root@172.16.0.135:"+path
            #save_log("debug", userImagePath+filename)
            remote = remote[0:len(remote)-1]
            #save_log("debug", remote)
            p = subprocess.Popen(['rsync','-ave','ssh',path+filename,remote],stdout=subprocess.PIPE)
    except Exception,e:
            save_log("debug",str(e))

def makeQrcode(branchId,studentId,filename,qrtxt):
    import qrcode
    url = '/go_static/users/'
    userImagePath = BASE_DIR+USER_IMAGE_DIR
    if branchId:
        userImagePath = userImagePath+branchId+'/'
        url = url + branchId + '/'
    if studentId:
        userImagePath = userImagePath+studentId+'/'
        url = url + studentId + '/'
    
    url = url+filename
    #print url
    try:
      img = qrcode.make('http://go2crm.cn'+qrtxt)
      imagefile = open(userImagePath+filename, 'wb+');
      img.save(imagefile,'JPEG')
      return url
    except:
        return url
    
    
            
    
#===============================================================================
# 1、20周5800
# 2、40周9800
# 3、80周18600
# 4、120周274005
# 5、4周试学1000
# 6、1周暑期班1000
#===============================================================================

def getUserFromExcel(filepath,branch_oid):
  index = 0
  if True:
    reload(sys)
    sys.setdefaultencoding('utf8')  # @UndefinedVariable
    branch = Branch.objects.get(id=branch_oid)# @UndefinedVariable
    print branch.branchCode
    print branch.id
    query = Q(city=branch.city.id)&Q(type=0)
    cityContracts = ContractType.objects.filter(query)
    ccts = {}
    if constant.DEBUG:
        print '1'
    for cct in cityContracts:
        if cct.code:
            ccts[cct.code] = cct.id
    if constant.DEBUG:
        print '2'
    
    excel = None
    try:
        excel = xlrd.open_workbook(BASE_DIR+USER_IMAGE_DIR+filepath)
    except Exception,e:
        print e
        excel = xlrd.open_workbook(BASE_DIR+USER_IMAGE_DIR+filepath+"x")
    if constant.DEBUG:
        print '3'
    table = excel.sheet_by_name(u'学籍')
    nrows = table.nrows #行数
    ncols = table.ncols #列数
    class_col = 0
    name_col = 1
    gender_col = 2
    birthday_col= 3
    mobile_col = 4
    c_singDate = 10
    c_beginDate = 11
    c_multi = 12
    c_type = 13
    c_weeks = 14
    c_paid = 15
    c_status = 16
    row = table.row_values(0)
    if constant.DEBUG:
        print '4'
    for j in range(ncols-1):
        if str(row[j]).strip() == u'班级代码':
            class_col = j
        if row[j] == u'姓名':
            name_col = j
        if row[j] == u'性别':
            gender_col = j

        if row[j] == u'出生年月':
            birthday_col = j
        if row[j] == u'手机号码':
            mobile_col = j
        if row[j] == u'签约日期':
            c_singDate = j
        if row[j] == u'合同开始日期':
            c_beginDate = j
        if row[j] == u'是否续费合同':
            c_multi = j
        if row[j] == u'合同类型':
            c_type = j
        if row[j] == u'实际周数':
            c_weeks = j
        if row[j] == u'实付金额':
            c_paid = j
        if row[j] == u'合同状态':
            c_status = j

    print 'class_col:'  + str(class_col)
    print 'c_singDate:' + str(c_singDate)
    print 'c_paid:' + str(c_paid)
    dup = 0

    gcs = GradeClass.objects.filter(branch=branch_oid)
    for g in gcs:
        g.delete()
    for i in range(1,nrows):
        row = table.row_values(i)
        gc = GradeClass()
        gc.branch = branch
        gc.name=row[class_col]
        
        gc.gradeClass_type = 1
        if type(gc.name) == float:
            gc.name = str(int(gc.name))
        
        if gc.name:
            if len(gc.name)>0:
                gcs = GradeClass.objects.filter(branch=branch).filter(name=gc.name)
                if gcs and len(gcs)>0:
                    continue;
                else:
                    gc.save()

    lastClass = None
    noindex = 0
    lastName = 'name'
    cindex = 0
    for i in range(1,nrows):
        dup = 0
        row = table.row_values(i)
        student = Student()
        classname = row[class_col]
        if type(classname) == float:
            classname = str(int(classname))
        if classname:
            lastClass = classname
        else:
            classname = lastClass
        
        student.name = row[name_col]
        
        if not student.name: 
            if not lastName:
                noindex = noindex + 1
        else:
            noindex = 0
        if noindex > 2:
            break
        lastName = student.name
        
        mstr = cellToStr(row[mobile_col])

        
        if mstr and len(mstr)>6:
            student.prt1mobile = mstr
            students = Student.objects.filter(prt1mobile=student.prt1mobile)
            if students: #记录已存在
                if len(students) >= 1: #有重复记录
                    st = None
                    for s in students:
                        
                        st = s
                        if str(st.branch.id) == branch_oid:#重复记录是本校区的
                            student = s
                            dup = 0
                            break
                        else:
                            student.dup = -1
                            student.resolved = -1
        else:
            dup = 1
        if gender_col>-1:
            student.gender = row[gender_col]
        if birthday_col > -1:
            birthday = cellToDate(row[birthday_col])
            student.birthday = birthday

        student.branch = branch
        student.branchName = branch.branchName
        
        con_status = cellToStr(row[c_status])

        contract_status = 0
        cstatus = 0
        try:
            contract_status = int(con_status)
        except:
            contract_status = 0
        if contract_status == 1:
            cstatus = 0
            student.status = 1
        elif contract_status == 2:
            cstatus = 2
            student.status = 3
        else:
            cstatus = 2
            student.status = 0
        
        #contract info
        singDate = cellToDate(row[c_singDate])

        paidStr = cellToStr(row[c_paid])
        paid = -1
        if paidStr:
            paid = int(paidStr)
        weeksStr = cellToStr(row[c_weeks])
        weeks = -1
        if weeksStr:
            weeks = int(weeksStr)
        
        if dup == 0:
          try:
 
            student.save()
            index = index +1
            if index == 1:
                print singDate
                print paid
                print weeks
                print cstatus
                
            if singDate and paid > -1 and weeks > -1 and cstatus == 0:
                print 'can add contract'
                beginDate = cellToDate(row[c_beginDate])
                multi = 1
                try:
                    multi = int(cellToStr(row[c_multi]))
                except:
                    multi = 1
                contractType = None
                try:
                    contractType = ccts[cellToStr(row[c_type])]
                except:
                    contractType = None
                contract = Contract()
                contract.singDate = singDate
                contract.student_oid = str(student.id)
                contract.branch = branch
                contract.beginDate = beginDate
                contract.status = cstatus
                contract.paid = paid
                contract.weeks = weeks 
                contract.multi = multi
                contract.contractType = contractType
                ccs = Contract.objects.filter(student_oid=contract.student_oid)
                for c in ccs:
                    c.delete()
                
                contract.save()

                csss = []
                csss.append(contract)
                student.contract = csss
                student.save()
                cindex = cindex + 1
            
            if student.status == 1:
              gcstudents = []
              try:
                gcs = GradeClass.objects.filter(name=classname).filter(branch=branch.id)
                gc = None
                if gcs and len(gcs)>0:
                    #print classname + '-' + student.name
                    gc = gcs[0]
                    gcstudents = gc.students
                    if gcstudents and len(gcstudents)>0:
                        okmsg = 1
                    else:
                        gcstudents = []
                    gcstudents.append(student)
                    gc.students = gcstudents

                    gc.save()
                    student.gradeClass = str(gc.id)
                    student.save()
              except Exception,e:
                print e
                gc=None
          except Exception,e:
              print e 
        else:
            dup = 0
  print '[students]' + str(index)
  print '[contracts]' + str(cindex)
  return index

def getUserFromExcel2(filepath,branch_oid):
  index = 0
  if True:
    reload(sys)
    sys.setdefaultencoding('utf8')  # @UndefinedVariable
    branch = Branch.objects.get(id=branch_oid)# @UndefinedVariable
    print branch.branchCode
    excel = None
    try:
        excel = xlrd.open_workbook(BASE_DIR+USER_IMAGE_DIR+filepath)
    except:
        excel = xlrd.open_workbook(BASE_DIR+USER_IMAGE_DIR+filepath+"x")
    table = excel.sheet_by_name(u'学籍')
    nrows = table.nrows #行数
    ncols = table.ncols #列数
    
    name_col = 0
    gender_col = 1
    callInTime_col = 4
    
    branch_col = 6
    demo_col = 7
    source_col = 9
    proba_col = 10
    mobile_col = 12
    pr1 = 13
    mobile2_col = 14
    pr2 = 15
    birthday_col= 18
    school_col = 20
    regTeacher_col = 24
    co_teacher_col = 25
    memo1_col = 27
    memo2_col = 29
    remind_col = 30
    memo3_col = 32
    regTime_col = 33
    
    row = table.row_values(0)

    
    dup = 0
    
    
    noindex = 0
    lastName = 'name'
    for i in range(1,nrows):
        row = table.row_values(i)
        student = Student()
        
        student.name = cellToStr(row[name_col])        
        if not student.name: 
            if not lastName:
                noindex = noindex + 1
        else:
            noindex = 0
        if noindex > 2:
            break
        lastName = student.name
            
        
        mstr = cellToStr(row[mobile_col])
        
        if mstr and len(mstr)>6:
            student.prt1mobile = mstr
            students = Student.objects.filter(prt1mobile=student.prt1mobile)
            if students: #记录已存在
                if len(students) >= 1: #有重复记录
                    st = None
                    for s in students:
                        
                        st = s
                        if str(st.branch.id) == branch_oid:#重复记录是本校区的
                            student = s
                            break
                        else:
                            student.dup = -1
                            student.resolved = -1
        else:
            dup = 1
        student.branch = branch
        student.branchName = branch.branchName
        if not student.gender:
            student.gender = cellToStr(row[gender_col])
        
        if dup == 0:
            student.save()
            index = index +1
            
  return index

def cellToStr(cell,debug=None):
    
    mstr = ''
    if type(cell) is float:  
        if debug:
           print 'isFloat'
        mstr = repr(cell).split(".")[0]
    else:
        if debug:
            print 'isStr'
        mstr = str(cell)
    mstr = mstr.strip()
    
    return mstr

def cellToDate(cell,debug=None):
    res = None
    try:
        mstr = str(cell)
        #if type(cell) is float:  
         #   mstr = repr(cell).split(".")[0]
        if debug:
            print '[date 0]'+str(mstr)
        if len(mstr.split('.'))<3:
            mstr = '2017.'+mstr
        if mstr[0:2] != '20':
            mstr = '20'+mstr
        if debug:
            print '[date 1]'+str(mstr)
        if mstr and len(mstr)>=8:
            mstr = mstr[0:len(mstr)]
            res = datetime.datetime.strptime(mstr,"%Y.%m.%d")
        if debug:
            print  '[date----end]'+str(res)   
    except Exception,e:
        print e
    
    return res

def getMessage(login_teacher,isRead,isDone=None):
    messages = None
    if login_teacher:
        query = Q(toTeacher_oid=str(login_teacher))
        if isRead == 0 or isRead == 1:
            query = query&Q(isRead=isRead)
        messages = Message.objects.filter(query).order_by("-sendTime")  # @UndefinedVariable
    return messages

def sendMessage(fromBranch,from_teacher,from_teacher_name,to_teacher,txt,isDone,url):
    try:
        query = Q(message=txt)&Q(toTeacher_oid=to_teacher)
        m = Message.objects.filter(query)  # @UndefinedVariable
        if m and len(m) > 0:
            return
        message = Message()
        message.isRead = 0
        message.toTeacher_oid = to_teacher
        message.fromTeacher_oid = from_teacher
        message.fromTeacherName = from_teacher_name
        message.fromBranchName = fromBranch
        message.message = txt
        message.todoUrl = url
        message.sendTime = getDateNow(8)
        message.save()
        #print '[to teacher]'+str(message.toTeacher_oid)
    except Exception,e:
        #print to_teacher
        print e
    return

def addTrackToStudent(student):
    has = False
    try:
       query = Q(student=student.id)&Q(track_txt__ne=u'总部新推送')&Q(track_txt__ne=u'总部新分配')
       tracks = StudentTrack.objects.filter(query).order_by("-trackTime")
       if tracks and len(tracks)>0:
           student.track = "["+tracks[0].trackTime.strftime('%Y%m%d')+"]"+tracks[0].track_txt 
           student.save()
           has = True
    except:
        print student.id
    return has

def saveTrack(isAdd,student,trackId,trackTime,teacher_oid,track_txt,important=None):
    if isAdd:
        studentTrack = StudentTrack(student=student)
    else:
        studentTrack = StudentTrack.objects.get(id=trackId)
    if True:#try:
        studentTrack.recordTime = getDateNow()+datetime.timedelta(hours=8)
        if not trackTime:
            studentTrack.trackTime = studentTrack.recordTime
        else:
            studentTrack.trackTime = trackTime
        t = Teacher.objects.get(id=teacher_oid)# @UndefinedVariable
        studentTrack.teacher = t
        studentTrack.branch = str(t.branch.id)
        studentTrack.track_txt = track_txt
        if important:
            studentTrack.important = important
        studentTrack.save()
        
        #=======================================================================
        # 联络记录保存进学生信息
        #=======================================================================
        addTrackToStudent(student)
        
        return 0

def getNoClassStudent(branch):
    query = Q(branch=branch)&Q(gradeClass__ne=None)&Q(status=constant.StudentStatus.sign)
    students = Student.objects.filter(query)
    for s in students:
        if s.gradeClass:
            try:
                query = Q(id=s.gradeClass)&Q(gradeClass_type=1)&Q(deleted__ne=1)
                gc = GradeClass.objects.filter(query)
                if not gc or len(gc) < 1:
                    print 'delete 1'
                    s.gradeClass = None
                    s.save()
                #print gc.name
            except:
                print 'delete'
                s.gradeClass = None
                s.save()
    noclassquery = Q(branch=branch)&(Q(gradeClass=None)|Q(gradeClass=''))&Q(status=constant.StudentStatus.sign)
    
    students = Student.objects.filter(noclassquery).order_by('name')
    return students

def getCheckins(studentId):
            lessonCheckin = 0
            query = Q(student=str(studentId))&(Q(type=1)|Q(type=3))&Q(checked=True)&Q(value__ne=0)
            
            ls = Lesson.objects.filter(query)  # @UndefinedVariable
            if constant.DEBUG:
                        print '5'
            if ls and len(ls) > 0:
                if constant.DEBUG:
                        print '6'
                temp = []
                for l in ls:
                  try:
                    gc = GradeClass.objects.get(id=l.gradeClass.id)
                    oriLesson = Lesson.objects.get(id=l.lessonId)  # @UndefinedVariable
                    if oriLesson and oriLesson.value and oriLesson.value != l.value:
                        l.value = oriLesson.value
                        l.save()
                        #print '[value wrong]'
                    if not l.value:
                        l.value = 1
                    if constant.DEBUG:
                        print '[lesson value]' + str(l.value)
                    
                    lessonCheckin = float(lessonCheckin + l.value)
                    if constant.DEBUG:
                        print 'lessons after add one' + str(lessonCheckin)
                  except Exception,e:
                      print e
                      err = 1
            if constant.DEBUG:
                        print '[checkin lessons]' + str(lessonCheckin)
            return lessonCheckin

def getLessonLeft(student):
        if constant.DEBUG:
                        print '[in getLessonLeft]'
        id = student.id
        sd = None #最近签约日期
        allLesson = 0 #全部合同周数
        lessonCheckin = 0 #本人签到数
        commonCheckin = 0 #共用合同者总计的签到数
        lessonLeft = 0
        query2 = None
        contracts = None #全部有效或已正常结束合同，不包括退费
        sibling = None
        if student.siblingId: #是附账户，找到主账户
            try:
               sibling = Student.objects.get(id=student.siblingId)
               contracts = Contract.objects.filter(student_oid=student.siblingId).filter(status__lt=2)
            except:
                contracts = None
        else:
            contracts = Contract.objects.filter(student_oid=str(id)).filter(status__lt=2)
        if constant.DEBUG:
                        print '2'
        
        for c in contracts:
            if c.weeks:
                allLesson = allLesson + c.weeks
            elif c.contractType:
                allLesson = allLesson + c.contractType.duration
            if not sd:
                if c.status == 0:
                    sd = c.singDate
            if sd:
                if c.status == 0 and c.singDate > sd:
                    sd = c.singDate
        if constant.DEBUG:
                        print '3'
        
        if sibling:#本人附账户，查主账户及所有附账户签到
            commonCheckin = getCheckins(sibling.id)
            if sibling.lessons != commonCheckin:
                sibling.lessons = commonCheckin
                sibling.save() #保存主账户已签到课程
                
            query = Q(siblingId=student.siblingId)
            siblings = Student.objects.filter(query)
            for sib in siblings: #附账户
                sibLessons = getCheckins(sibling.id)
                if sib.lessons != sibLessons:
                    sib.lessons = sibLessons
                    sib.save()
                commonCheckin = commonCheckin + sib.lessons
                if sib.id == student.id: #本人的签到数
                    lessonCheckin = sib.lessons
            lessonLeft = allLesson - commonCheckin
            if sibling.lessonLeft !=lessonLeft or sibling.commonCheckin != commonCheckin:
                sibling.lessonLeft = lessonLeft
                sibling.commonCheckin = commonCheckin
                sibling.save()
            for sib in siblings:
                if sib.lessonLeft != lessonLeft or sib.commonCheckin != commonCheckin:
                    sib.lessonLeft = lessonLeft
                    sib.commonCheckin = commonCheckin
                    sib.save()
            
        elif student.siblingName or student.siblingName2 or student.siblingName3: #本人主账户，查所有附账户签到
            commonCheckin = getCheckins(student.id)
            if student.lessons != commonCheckin:
                student.lessons = commonCheckin
                student.save() #保存主账户已签到课程
            query = Q(siblingId=str(id))
            siblings = Student.objects.filter(query)
            for sib in siblings: #附账户
                sibLessons = getCheckins(sib.id)
                if sib.lessons != sibLessons:
                    sib.lessons = sibLessons
                    sib.save()
                commonCheckin = commonCheckin + sib.lessons
                
            lessonLeft = allLesson - commonCheckin
            if student.lessonLeft !=lessonLeft  or student.commonCheckin != commonCheckin:
                student.lessonLeft = lessonLeft
                student.commonCheckin = commonCheckin
                student.save()
            for sib in siblings:
                if sib.lessonLeft != lessonLeft or sib.commonCheckin != commonCheckin:
                    sib.lessonLeft = lessonLeft
                    sib.commonCheckin = commonCheckin
                    sib.save()
            
        else:
            if constant.DEBUG:
                        print '4'
            lessonCheckin = getCheckins(student.id)
            lessonLeft = allLesson - lessonCheckin
            toSave = False
            if student.lessons != lessonCheckin:
                student.lessons = lessonCheckin
                toSave = True
            if student.lessonLeft != lessonLeft:
                student.lessonLeft = lessonLeft
                toSave = True
            if toSave:
                student.save()
                
        return allLesson,sd,lessonLeft
    
def getCityBranch(cityId):
    query = Q(city=cityId)&Q(type__ne=1)&Q(type__ne=2)&Q(type__ne=3)&Q(deleted__ne=True)
    branches = Branch.objects.filter(query).order_by("sn")  # @UndefinedVariable
    return branches

def getTeacherClasses(teacherId):
    query = Q(teacher=teacherId)&Q(gradeClass_type=constant.GradeClassType.normal)&Q(deleted__ne=1)
    gradeClasses = GradeClass.objects.filter(query).order_by("start_date")
    return gradeClasses

def getBranches(login_teacher,all=None):
    branchs = None
    if all:
        branchs = Branch.objects.all().order_by("sn")  # @UndefinedVariable
    else:
        query = Q(deleted__ne=True)
        if login_teacher.username != 'admin':
            query = query&Q(city=login_teacher.cityId)
        branchs = Branch.objects.filter(query).order_by("sn")  # @UndefinedVariable
    #else:
     #   branchs = Branch.objects.all().order_by("sn")  # @UndefinedVariable
    return branchs

def isFinance(branchId):
    isFinance = False
    if branchId == constant.BJ_CAIWU:
        isFinance = True
    return isFinance